'use strict';

/*  
    a calculater
*/


const numberButtons = document.querySelectorAll('.number');
const operaterButtons = document.querySelectorAll('.operater');
const previousDisplayVal = document.querySelector('.previous-operand');
const currentDisplayVal = document.querySelector('.current-operand');



numberButtons.forEach((button) =>{
    button.addEventListener('click', () =>{
        previousDisplayVal.innerHTML += button.value;
    });
});

operaterButtons.forEach((button) =>{
    button.addEventListener('click', () =>{
        previousDisplayVal.innerHTML += button.value;
    });
});

let clear = document.getElementById('clear');
	clear.addEventListener('click', () => {
		previousDisplayVal.innerHTML = '';
        currentDisplayVal.innerHTML = '';
	});

let equals = document.getElementById('equals');
    equals.addEventListener('click', () => {
       
        let expression = previousDisplayVal.innerHTML;
        let numbers = expression.split(/[-+*/]/);
        let operators = expression.split("").filter(c => "-+*/".includes(c));

        let result = parseFloat(numbers[0]);

        for (let i = 1; i < numbers.length; i++) {
        let operator = operators[i - 1];
        let number = parseFloat(numbers[i]);

        switch (operator) {
            case "*":
                result *= number;
                break;
            case "/":
                result /= number;
                break;
            case "+":
                result += number;
                break;
            case "-":
                result -= number;
                break;
            default:
                result = NaN;
                break;
        }
        currentDisplayVal.innerHTML = Number(result.toFixed(2)).toFixed(2);
    };
})



  